document.addEventListener("DOMContentLoaded", () => {  // ensure the DOM is fully loaded
  const user = JSON.parse(localStorage.getItem("user"));
  const logoutBtn = document.getElementById("logout-btn");

  logoutBtn.style.display = user ? "inline" : "none";         // show logout button if user is logged in

  if (user && location.hash === "#/") {            // redirect logged-in users from login page
    location.hash = "#/events";
  }

  window.addEventListener("hashchange", () => {        
    const user = JSON.parse(localStorage.getItem("user"));
    logoutBtn.style.display = user ? "inline" : "none";
  });
});
