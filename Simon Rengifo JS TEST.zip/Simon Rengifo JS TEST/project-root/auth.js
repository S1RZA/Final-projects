function renderLogin() {          // Function to render the login page and create the login form
  document.getElementById("app").innerHTML = `
  <div class="login-container">
    
    <form id="login-form">
      <h2>Login</h2>
      <label for="username">Username</label>
      <input type="text" id="username" placeholder="Username" required />
      <label for="password">Password</label>
      <input type="password" id="password" placeholder="Password" required />
      <button type="submit" id="login-button">Login</button>
      <p id="register-link">Don't have an account? <a href="#/register">Register here</a></p>
    </form>
    
  </div>`;
  // Add event listener for login form submission
  document.getElementById("login-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const username = e.target.username.value;
    const password = e.target.password.value;

    const res = await fetch(`http://localhost:3000/users?username=${username}&password=${password}`);
    const users = await res.json();

    if (users.length > 0) {
      localStorage.setItem("user", JSON.stringify(users[0]));
      location.hash = "#/events";
    } else {
      alert("Invalid credentials");
    }
  });
}
 // Function to render the registration page and create the registration form
  // This function is called when the user clicks on the "Register here" link in the login form
function renderRegister() {
  document.getElementById("app").innerHTML = `
    
    <form id="register-form">
      <label>Register</label>
      <input type="text" id="reg-username" placeholder="Fullname" required />
      <input type="email" id="reg-email" placeholder="enter your email" required />
      <input type="password" id="reg-password" placeholder="Password" required />
      <input type="password" id="verify-password" placeholder="confirm password"/>
      <select id="reg-role">
        <option value="user">User</option>
        <option value="admin">Admin</option>
      </select>
      <button type="submit" id="register-button">Register</button>
    </form>
    <p>Already have an account? <a href="#/">Login here</a></p>
  `;
  // Add event listener for registration form submission
  document.getElementById("register-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const username = document.getElementById("reg-username").value;
    const password = document.getElementById("reg-password").value;
    const role = document.getElementById("reg-role").value;
    const email = document.getElementById("reg-email").value;

    const checkRes = await fetch(`http://localhost:3000/users?username=${username}`);
    const existing = await checkRes.json();
    if (existing.length > 0) {
      alert("Username already exists.");
      return;
    }
    if (password !== document.getElementById("verify-password").value) {
      alert("Passwords do not match.");
      return;
    }
    const newUser = { username, password, role, email };
    await fetch("http://localhost:3000/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newUser)
    });

    alert("Registration successful. You can now log in.");
    e.target.reset();
    location.hash = "#/";
  });
}

function logout() {
  localStorage.removeItem("user");
  location.hash = "/";
}
