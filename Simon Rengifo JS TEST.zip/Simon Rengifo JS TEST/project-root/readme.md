## Nombre: Simon Rengifo Zapata 
## Clan: Gosling 
## correo: simonrz1212@hotmail.com 
## documento: 1020417710


## Explanation of the code

# In this project you will find multiple files and settings, let me explain to you the main files and their purpouse.

# app.js its main purpose as it name says is the proper function of the web
# auth.js is made to authenticate the database of users, it includes the register and login, the html their functionalities and validations

# the db.json is the database of the whole project, here we'll be storage every important detail of the page and user data, and also server data

# router.js is in charge to handle the SPA (Single page application) this allows a faster and more comfortable UI 

# and finally you'll find the html and the CSS, the structure and the desing of the webpage

# important details, you must install the package.json and also run the JSON server, verify to install al the dependences before running the codes