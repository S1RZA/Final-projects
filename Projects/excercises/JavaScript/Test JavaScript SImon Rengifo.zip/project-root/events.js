async function renderEvents() {    // Check if user is logged in
  const user = JSON.parse(localStorage.getItem("user"));
  if (!user) {
    location.hash = "/";
    return;
  }
   // Render events for the logged-in user
  try {
    const res = await fetch("http://localhost:3000/events");
    const events = await res.json();
    const isAdmin = user.role === "admin";
    const isUser = user.role === "user";

    let html = `<div id="data-container"><div><ul id="data-events"><li>name</li><li>Description</li><li>Capacity</li><li>Date</li></ul><ul id="event-list">`;
    events.forEach((event) => { 
      html += `
        <li data-id="${event.id}" class="display-events">
          <strong>${event.name}</strong> ${event.description}, ${event.capacity} (${event.date})
          ${isAdmin ? `
            <button class="edit-btn">Edit</button>
            <button class="delete-btn">Delete</button>
          ` : ""} 
            ${isUser ? `
            <button id="joinBtn" onclick="capacity(${event.id})">Join Event</button><p id="${event.id}">estatus</p>` : ""}
        </li> `;
    });
    html += `</ul></div>`;

    if (isAdmin) {
      html += `
      <div id="add-event-container">
        <h3>Add Event</h3>
        <form id="add-event-form">
          <input name="name" placeholder="Name" required />
          <input name="description" placeholder="Description" required />
          <input name="capacity" type="number" placeholder="Capacity" required />
          <input name="date" placeholder="Date" required />
          <input name="joinedCount" type="number" placeholder="Joined Count" required />
          <button type="submit">Add Event</button>
        </form>
        </div>
        </div>
      `;
    }

    document.getElementById("app").innerHTML = html;

    // Add new event
    if (isAdmin) {
      document.getElementById("add-event-form").addEventListener("submit", async (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        const event = Object.fromEntries(formData);
        event.capacity = parseInt(event.capacity);
        event.joinedCount = parseInt(event.joinedCount);
        await fetch("http://localhost:3000/events", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(event)
        });
        renderBooks();
      });

      // Event delegation for edit/delete
      document.getElementById("event-list").addEventListener("click", async (e) => {
        const li = e.target.closest("li");
        const eventId = li?.dataset.id;

        if (!eventId) return;

        // DELETE data
        if (e.target.classList.contains("delete-btn")) {
          await fetch(`http://localhost:3000/events/${eventId}`, {
            method: "DELETE"
          });
          renderEvents();
        }

        // EDIT data
        if (e.target.classList.contains("edit-btn")) {
          const event = await fetch(`http://localhost:3000/events/${eventId}`).then(res => res.json());

          li.innerHTML = `
            <form class="edit-event-form">
              <input name="name" value="${event.name}" required />
              <input name="description" value="${event.description}" required />
              <input name="capacity" type="number" value="${event.capacity}" required />
              <input name="date" value="${event.date}" required />
              <input name="joinedCount" type="number" value="${event.joinedCount}" required />
              <button type="submit">Save</button>
              <button type="button" class="cancel-btn">Cancel</button>
            </form>
          `;

          // Save changes
          li.querySelector(".edit-event-form").addEventListener("submit", async (ev) => {
            ev.preventDefault();
            const formData = new FormData(ev.target);
            const updatedEvent = Object.fromEntries(formData);
            updatedEvent.capacity = parseInt(updatedEvent.capacity);
            updatedEvent.joinedCount = parseInt(updatedEvent.joinedCount);
            await fetch(`http://localhost:3000/events/${eventId}`, {
              method: "PATCH",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(updatedEvent)
            });
            renderEvents();
          });

          // Cancel edit
          li.querySelector(".cancel-btn").addEventListener("click", () => {
            renderEvents(); // Just reload the view
          });
        }
      });
    }      
  } catch (err) {       // Handle errors 
    console.error("Error loading events:", err);
    document.getElementById("app").innerHTML = "<p>Error loading events. Check server or console.</p>";
  }
}
 //counter for event capacity
// Function to handle joining an event and updating the capacity
async function capacity(eventId) {
  const user = JSON.parse(localStorage.getItem("user"));
  if (!user) {
    alert("Please log in to join an event.");
    return;
  }

  try {
    const res = await fetch(`http://localhost:3000/events/${eventId}`);
    const event = await res.json();

    if (event.joinedCount >= event.capacity) {
      alert("Event is full.");
      return;
    }

    event.joinedCount += 1;

    await fetch(`http://localhost:3000/events/${eventId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ joinedCount: event.joinedCount })
    });
  } catch (err) {
    console.error("Error joining event:", err);
  }
}