function router() {
  const routes = {
    "/": renderLogin,
    "/events": renderEvents,
    "/logout": logout,
    "/register" : renderRegister,
  };

  const path = location.hash.slice(1) || "/";
  const route = routes[path];

    if (localStorage.getItem("user") && (path === "/")) {
    location.hash = "#/events";
    return;
  }

  if (route) {
    route();
  } else {
    document.getElementById("app").innerHTML = "<h2>404 - Page Not Found</h2>";
  }
}

window.addEventListener("hashchange", router);
window.addEventListener("load", router);
